import 'package:amplify_analytics_pinpoint_dart/src/sdk/pinpoint.dart';
import 'package:amplify_common/amplify_common.dart' hide Event;
import 'package:built_collection/built_collection.dart';

class EventCreator {
  final int _maxEventTypeLength = 50;

  // TODO - should parsing logic of Analytics -> Request logic be separated?

  // TODO - store global attribute / metrics between sessions !!@!
  final MapBuilder<String, String> _globalAttributes =
      MapBuilder<String, String>();
  final MapBuilder<String, double> _globalMetrics =
      MapBuilder<String, double>();

  Event createPinpointEvent(String eventType, SessionBuilder? sessionBuilder,
      [AnalyticsEvent? analyticsEvent]) {
    if (eventType.length > _maxEventTypeLength) {
      /*
      log.error("The event type is too long, the max event type length is " +
          MAX_EVENT_TYPE_LENGTH
          + " characters.");
       */
      throw const AnalyticsException(
          "The eventType passed into create event was too long");
    }

    EventBuilder eventBuilder = EventBuilder();

    // Fill in defaults for all events
    // TODO: why doesn't Event have eventId field like AnalyticsEvent in Android?
    eventBuilder.eventType = eventType; // analyticsEvent.name;
    eventBuilder.sdkName = 'aws-sdk-dart';
    // TODO sdk-core getVersion manager?
    eventBuilder.clientSdkVersion = 'unknown';

    eventBuilder.session = sessionBuilder;

    eventBuilder.timestamp = DateTime.now().toIso8601String();

    // TODO: why does Android have uniqueID field that is ignored ...

    // TODO fill out:
    //eventBuilder.appTitle =
    //eventBuilder.appPackageName =
    //eventBuilder.appVersionCode =

    // TODO Not found in Dart
    // uniqueId ... -> generated as UUID, stored in sharedPrefs and retrieved afterwards
    // Android appDetails
    // Android deviceDetails

    //eventBuilder.attributes

    var eventAttrs = MapBuilder<String, String>(_globalAttributes.build());
    var eventMetrics = MapBuilder<String, double>(_globalMetrics.build());

    if (analyticsEvent != null) {
      _extractAnalyticsProperties(
          eventAttrs, eventMetrics, analyticsEvent.properties);
    }

    eventBuilder.attributes = eventAttrs;
    eventBuilder.metrics = eventMetrics;

    return eventBuilder.build();
  }

  void registerGlobalProperties(
    AnalyticsProperties globalProperties,
  ) {
    _extractAnalyticsProperties(
        _globalAttributes, _globalMetrics, globalProperties);
  }

  void unregisterGlobalProperties(List<String> propertyNames) {
    for (var key in propertyNames) {
      _globalAttributes.remove(key);
      _globalMetrics.remove(key);
    }
  }

  void _extractAnalyticsProperties(
      MapBuilder<String, String> attrs,
      MapBuilder<String, double> metrics,
      AnalyticsProperties analyticsProperties) {
    Map<String, Object> propertiesMap = analyticsProperties.getAllProperties();
    Map<String, String> propertiesTypesMap =
        analyticsProperties.getAllPropertiesTypes();

    propertiesTypesMap.forEach((k, v) {
      String type = propertiesTypesMap[k]!;

      switch (type) {
        case 'STRING':
          attrs[k] = propertiesMap[k] as String;
          break;
        case 'BOOL':
          attrs[k] = propertiesMap[k] as String;
          break;
        case 'INT':
          metrics[k] = propertiesMap[k] as double;
          break;
        case 'DOUBLE':
          metrics[k] = propertiesMap[k] as double;
          break;
        default:
      }
    });
  }
}
