import 'package:intl/intl.dart';

import '../../sdk/pinpoint.dart';
import 'flutter_app_lifecycle_observer.dart';
import 'flutter_shared_prefs.dart';

const String sessionStartEventType = '_session.start';
const String sessionStopEventType = '_session.stop';

/// TODO: why doesn't Android allow pause/resume of session
//final String _sessionPauseEventType = "_session.pause";
//final String _sessionResumeEventType = "_session.resume";

enum SessionState { inactive, active, paused }

typedef SessionFunc = Function(SessionBuilder);

/// Manage Session object
class SessionManager {
  final _maxIdLength = 8;

  late SessionFunc _onSessionStart;
  late SessionFunc _onSessionEnd;

  SessionBuilder? _sessionBuilder;
  SessionBuilder? get sessionBuilder => _sessionBuilder;

  late FlutterAppLifecycleObserver lifecycleObserver;

  final FlutterSharedPrefs _sharedPrefs;

  SessionManager(this._sharedPrefs,
      {required SessionFunc onSessionStart,
      required SessionFunc onSessionEnd}) {
    _onSessionStart = onSessionStart;
    _onSessionEnd = onSessionEnd;

    // TODO - TEMP initialize session
    // Android creates a blank session ...
    _executeStart();

    /// TODO - why does Android retrieve serialized Session JSON?
    ///
    /// TODO - if ! EnableTargeting, set session id to all 0s and start time to 0
    ///

    /// TODO : Android why does SessionClient pause/resume never get called?
    lifecycleObserver = FlutterAppLifecycleObserver(onForeground: () {
      startSession();
    }, onBackground: () {
      stopSession();
    });
    lifecycleObserver.startObserving();
  }

  void startSession() {
    _executeStop();
    _executeStart();
  }

  void stopSession() {
    _executeStop();
  }

  void startSessionTracking() {
    lifecycleObserver.startObserving();
  }

  void stopSessionTracking() {
    lifecycleObserver.stopObserving();
  }

  SessionState getSessionState() {
    if (_sessionBuilder == null) return SessionState.inactive;

    return SessionState.active;

    // Android doesn't call code path for pause/resume of Session ..
    if (sessionBuilder!.stopTimestamp == null) {
      return SessionState.active;
    } else {
      return SessionState.paused;
    }
  }

  String _generateSessionId() {
    String id = _sharedPrefs.getUniqueId();
    id = id.padLeft(_maxIdLength, '_');
    id = id.substring(0, _maxIdLength);

    DateTime date = DateTime.now().toUtc();

    // TODO: confirm locale is set correctly
    DateFormat dateFormat = DateFormat('yyyyMMdd-HHmmss', 'en_US');

    String dateString = dateFormat.format(date) + date.millisecond.toString();

    return id + '-' + dateString;
  }

  void _executeStart() {
    // TODO update endpoint?
    // Android updates endpoint profile here ...
    // Which involves copying EndpointProfile fields into EndpointRequest
    // And calling pinpoint service, updateEndpoint ...

    _sessionBuilder = SessionBuilder()
      ..id = _generateSessionId()
      ..startTimestamp = DateTime.now().toIso8601String();

    _onSessionStart(_sessionBuilder!);

    // In Android startTimestamp is ISO 8601 string
    //session.withStartTimestamp(DateUtils.formatISO8601Date(new Date(internalEvent.getSession().getSessionStart())));
  }

  void _executeStop() {
    if (_sessionBuilder == null) return;

    _sessionBuilder!.stopTimestamp = DateTime.now().toIso8601String();

    _onSessionEnd(_sessionBuilder!);

    // TODO clear eventSourceAttributes

    _sessionBuilder = null;
  }
}
