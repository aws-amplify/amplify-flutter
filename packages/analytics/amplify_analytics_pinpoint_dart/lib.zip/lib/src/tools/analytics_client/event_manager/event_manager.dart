import 'package:amplify_analytics_pinpoint_dart/src/tools/analytics_client/flutter_shared_prefs.dart';
import 'package:amplify_analytics_pinpoint_dart/src/tools/endpointer_helper.dart';
import 'package:built_collection/built_collection.dart';
import 'package:uuid/uuid.dart';

import '../../../sdk/pinpoint.dart';
import 'events_storage_adapter.dart';

/// Manage sending of AnalyticsEvent
///
///
///
///

class EventManager {
  final EventStorageAdapter _storageAdapter = EventStorageAdapter();

  final String _appId;
  final PinpointClient _pinpointClient;
  final FlutterSharedPrefs _sharedPrefs;

  final _uuid = const Uuid();

  EventManager(this._appId, this._sharedPrefs, this._pinpointClient);

  void recordEvent(Event event) {
    _storageAdapter.saveEvent(event);
  }

  Future<void> flushEvents() async {
    List<Event> eventsToFlush = await _storageAdapter.retrieveEvents();

    var eventsMap = <String, Event>{};
    for (var event in eventsToFlush) {
      eventsMap[_uuid.v1()] =
          event; // TODO verify how event ids are created in Android
    }

    // TODO : get targeting client's endpoint for submission

    // TODO : what is unique id ??? from Android

    // Events batch map is endpointId - eventsBatch ....

    // EventsBatchBuilder batchBuilder = EventsBatchBuilder();
    EventsBatch batch = EventsBatch(
        endpoint: EndpointHelper.sampleEndpoint,
        events: BuiltMap<String, Event>(eventsMap));

    // TODO : temp get unique id directly from unique id manager

    var batchItems =
        BuiltMap<String, EventsBatch>({_sharedPrefs.getUniqueId(): batch});
    await _pinpointClient.putEvents(PutEventsRequest(
        applicationId: _appId,
        eventsRequest: EventsRequest(batchItem: batchItems)));
  }
}
