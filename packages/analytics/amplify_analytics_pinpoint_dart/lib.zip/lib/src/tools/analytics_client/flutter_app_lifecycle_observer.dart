//import 'package:flutter/material.dart';

class FlutterAppLifecycleObserver {
  //extends WidgetsBindingObserver {
  late Function _onApplicationEnterForeground;
  late Function _onApplicationEnterBackground;

  bool _isObserving = false;

  FlutterAppLifecycleObserver(
      {required Function onForeground, required Function onBackground}) {
    _onApplicationEnterForeground = onForeground;
    _onApplicationEnterBackground = onBackground;
  }

  void startObserving() {
    if (_isObserving) return;

    _isObserving = true;
    //WidgetsBinding.instance.addObserver(this);
  }

  void stopObserving() {
    _isObserving = false;
    //WidgetsBinding.instance.removeObserver(this);
  }

  /*
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.resumed:
        _onApplicationEnterForeground();
        // startSession
        break;
      // foreground inactive due to phone call / etc.
      case AppLifecycleState.inactive:
        _onApplicationEnterBackground();
        // stopSession
        // submitEvents
        break;
      // backgrounded
      case AppLifecycleState.paused:
        // stopSession
        // submitEvents
        break;
      // flutter engine running without view
      case AppLifecycleState.detached:
        break;
      default:
    }
  }
   */
}
