import 'dart:async';

//import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

/// Manage storage and retrieval of unique id
///
///

// TODO - how to extract previous unique id keys? from Android and iOS?

class FlutterSharedPrefs {
  // Stored Keys
  static const String uniqueIdKey = 'UniqueId';

  static const String eventsGlobalAttrsKey = 'EventsGlobalAttributesKey';

  static const String endpointGlobalAttrsKey = 'EndpointGlobalAttributesKey';

  static const String eventsGlobalMetricsKey = 'EventsGlobalMetricsKey';

  static const String endpointGlobalMetricsKey = 'EndpointGlobalMetricsKey';

  //late final SharedPreferences? _instance;

  // late Completer<SharedPreferences> _instance;

  //late Future<SharedPreferences> _instance;

  static const _uuid = Uuid();

  // temp
  static String? uniqueId;

  // Keep as class to allow extensibility / inheritance
  FlutterSharedPrefs() {
    //_instance = SharedPreferences.getInstance();
  }

  Future<void> saveJson(String key, String json) async {
    // await save operation
  }

  String getJson(String key) {
    return 'hi';
  }

  String getUniqueId() {
    uniqueId ??= _uuid.v1();

    return uniqueId!;
    /*
    return _instance.then((sharedPreferences) {
      String? uniqueId = sharedPreferences.getString(UNIQUE_ID_KEY);
      if (uniqueId != null) {
        return uniqueId;
      } else {
        uniqueId = _uuid.v1();
        sharedPreferences.setString(UNIQUE_ID_KEY, uniqueId);
        return uniqueId;
      }
    });
     */
  }
}
