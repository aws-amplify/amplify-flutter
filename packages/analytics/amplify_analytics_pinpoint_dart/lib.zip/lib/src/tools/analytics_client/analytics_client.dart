import 'dart:async';

import 'package:amplify_analytics_pinpoint_dart/src/tools/analytics_client/event_manager/event_manager.dart';
import 'package:amplify_analytics_pinpoint_dart/src/tools/analytics_client/flutter_shared_prefs.dart';
import 'package:amplify_analytics_pinpoint_dart/src/tools/analytics_client/session_manager.dart';
import 'package:amplify_analytics_pinpoint_dart/src/tools/analytics_client/stoppable_timer.dart';
import 'package:amplify_common/amplify_common.dart' hide Event;

import '../../sdk/pinpoint.dart';

import '../endpoint_client.dart';
import 'event_creator.dart';

/// Layer above PinpointClient
/// Handle lifecycle of PinpointClient
/// Provide PinpointClient to specialized subclasses
///
///

// TODO: why does Android AnalyticsClient have toJson?

class AnalyticsClient {
  // External Dependenceis
  late PinpointClient _pinpointClient;
  late String _appId;
  late FlutterSharedPrefs _sharedPrefs;

  // Should be managed by SessionTracker
  late final SessionManager _sessionManager; // = SessionManager();

  late final EventManager _eventManager;

  late final StoppableTimer _autoEventSubmitter;

  late final EventCreator _eventCreator = EventCreator();

  late final EndpointClient _endpointClient;

  AnalyticsClient(this._appId, this._sharedPrefs, this._pinpointClient);

  Future<void> configure() async {
    /// TODO - clarify - what is behavior on app refresh / hot reload?
    _autoEventSubmitter =
        StoppableTimer(const Duration(seconds: 10), (Timer t) => flushEvents);

    _eventManager = EventManager(_appId, _sharedPrefs, _pinpointClient);

    _sessionManager = SessionManager(_sharedPrefs, onSessionEnd: (sb) {
      _eventManager.recordEvent(
          _eventCreator.createPinpointEvent(sessionStopEventType, sb));
      _eventManager.flushEvents();
    }, onSessionStart: (sb) async {
      await _endpointClient.updateEndpoint();
      _eventManager.recordEvent(
          _eventCreator.createPinpointEvent(sessionStartEventType, sb));
    });

    _endpointClient = EndpointClient(_appId, _sharedPrefs, _pinpointClient);
  }

  Future<void> flushEvents() async {
    await _eventManager.flushEvents();
  }

  void recordEvent(AnalyticsEvent analyticsEvent) {
    Event pinpointEvent = _eventCreator.createPinpointEvent(
        analyticsEvent.name, _sessionManager.sessionBuilder, analyticsEvent);
    _eventManager.recordEvent(pinpointEvent);
  }

  void enable() {
    _autoEventSubmitter.start();
    _sessionManager.startSessionTracking();
  }

  void disable() {
    _autoEventSubmitter.stop();
    _sessionManager.stopSessionTracking();
  }

  void registerGlobalProperties(
    AnalyticsProperties globalProperties,
  ) {
    _eventCreator.registerGlobalProperties(globalProperties);
  }

  void unregisterGlobalProperties(List<String> propertyNames) {
    _eventCreator.unregisterGlobalProperties(propertyNames);
  }

  Future<void> identifyUser(
    String userId,
    AnalyticsUserProfile userProfile,
  ) async {
    await _endpointClient.setUser(userId, userProfile);
  }
}
