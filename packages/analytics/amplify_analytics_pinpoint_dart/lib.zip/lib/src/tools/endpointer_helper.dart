import 'package:amplify_analytics_pinpoint_dart/src/sdk/pinpoint.dart';
import 'package:built_collection/built_collection.dart';

class EndpointHelper {
  // ? Need endpoint
  // Unfortunately the UpdateEndpointRequest doesn't actually
  // take an Endpoint object even though they are related ....

  // So the EndpointRequest must extract all the fields from the Endpoint object
  // each time an endpoint is updated

  // While the Endpoint object is what is sent for sendEvents ...

  //AWSEndpoint endpoint = endpointResolver.resolve("service", region);

  static PublicEndpoint sampleEndpoint = PublicEndpoint(
    address: "address",
    attributes: BuiltListMultimap({
      'test': ['test', 'test0']
    }),
    channelType: ChannelType.inApp,
    demographic: EndpointDemographic(
        appVersion: 'appversion',
        locale: 'locale',
        make: 'make',
        model: 'model',
        modelVersion: 'modelVersion',
        platform: 'platform',
        platformVersion: 'platformVersion',
        timezone: 'EST'),
    effectiveDate: DateTime.now()
        .toIso8601String(), // '2020-04-30T00:00:00.000Z', // MUST BE ISO 8601 format
    endpointStatus: 'effectiveStatus',
    location: EndpointLocation(
        city: 'city',
        country:
            'AF', // MUST BE ISO 3166-1 Alpha-2 or Alpha-3 codes or UN M.49 numeric-3 area code,
        latitude: 10,
        longitude: 10,
        postalCode: 'postalcode',
        region: 'region'),
    metrics: BuiltMap({'string': 10.0}),
    optOut: 'NONE', // NONE or ALL
    requestId: 'requestId',
    user: EndpointUser(
        userAttributes: BuiltListMultimap({
          'string': ['string0', 'string1']
        }),
        userId: 'userId'),
  );
}
