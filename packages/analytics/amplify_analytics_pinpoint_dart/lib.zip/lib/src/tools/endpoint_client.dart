import 'dart:convert';

import 'package:amplify_analytics_pinpoint_dart/src/tools/endpoint_global_fields_manager.dart';
import 'package:amplify_common/amplify_common.dart';
import 'package:built_collection/built_collection.dart';

import '../sdk/pinpoint.dart';
import 'analytics_client/flutter_shared_prefs.dart';

class EndpointClient {
  // string userAgent = PinpointManager.class.getName + / + versionUtils.getVersion

  // max event operations = 1000

  // Current Endpoint being managed
  late PublicEndpointBuilder _endpointBuilder;
  late EndpointGlobalFieldsManager _globalFieldsManager;

  // TODO how is this passed?
  late String _appId;
  late PinpointClient _pinpointClient;
  late FlutterSharedPrefs _sharedPrefs;

  // External dependencies
  EndpointClient(this._appId, this._sharedPrefs, this._pinpointClient) {
    _globalFieldsManager = EndpointGlobalFieldsManager();

    _endpointBuilder = PublicEndpointBuilder();

    // TODO android uses SDKGlobalConfiguration.getGlobalTimeOffset secs
    _endpointBuilder.effectiveDate = DateTime.now().toIso8601String();
    // TODO get device demographic info
    _endpointBuilder.demographic = EndpointDemographicBuilder()
      ..appVersion = 'appversion'
      ..locale = 'locale'
      ..make = 'make'
      ..model = 'model'
      ..modelVersion = 'modelVersion'
      ..platform = 'platform'
      ..platformVersion = 'platformVersion'
      ..timezone = 'EST';
    // TODO get location data
    _endpointBuilder.location = EndpointLocationBuilder()
      ..city = 'city'
      ..country = 'AF'
      ..latitude = 10
      ..longitude = 10
      ..postalCode = 'postalcode'
      ..region = 'region';
    _endpointBuilder.requestId = _sharedPrefs.getUniqueId();

    // Auto set within Android's EndpointProfile

    /*
    applicationId -> not found
    endpointId -> the unique id (is this requestId?)
     */

    // TODO verify this is push notification related:
    /*
    channelType -> notificationClient.channelType
    address -> notificationClient.deviceToken
    optOut -> notificationClient -> NONE/ALL
     */
  }

  void addAttribute(String name, List<String> values) =>
      _globalFieldsManager.addAttribute(name, values);
  void removeAttribute(String name) =>
      _globalFieldsManager.removeAttribute(name);
  void addMetric(String name, double value) =>
      _globalFieldsManager.addMetric(name, value);
  void removeMetric(String name) => _globalFieldsManager.removeMetric(name);

  // update the UserProfile on the EndpointProfile
  Future<void> setUser(
      String userId, AnalyticsUserProfile copyFromProfile) async {
    EndpointUserBuilder newUserBuilder = EndpointUserBuilder();

    // TODO  - follow Andorid and allow for
    // -> newUserBuilder.userAttributes

    newUserBuilder.userId = userId;

    if (copyFromProfile.name != null) {
      addAttribute('name', [copyFromProfile.name!]);
    }
    if (copyFromProfile.email != null) {
      addAttribute('email', [copyFromProfile.email!]);
    }
    if (copyFromProfile.plan != null) {
      addAttribute('plan', [copyFromProfile.plan!]);
    }

    if (copyFromProfile.location != null) {
      var newLoc = copyFromProfile.location!;
      var lb = _endpointBuilder.location;

      if (newLoc.latitude != null) lb.latitude = newLoc.latitude;
      if (newLoc.longitude != null) lb.longitude = newLoc.longitude;
      if (newLoc.postalCode != null) lb.postalCode = newLoc.postalCode;
      if (newLoc.city != null) lb.city = newLoc.city;
      if (newLoc.region != null) lb.region = newLoc.region;
      if (newLoc.country != null) lb.country = newLoc.country;
    }

    if (copyFromProfile.properties != null) {
      var typesMap = copyFromProfile.properties!.getAllPropertiesTypes();
      copyFromProfile.properties!.getAllProperties().forEach((key, value) {
        if (typesMap[key] == 'DOUBLE' || typesMap[key] == 'INT') {
          _globalFieldsManager.addMetric(key, value as double);
        } else {
          _globalFieldsManager.addAttribute(key, [value.toString()]);
        }
      });
    }

    // TODO: Android has AWSPinpointUserProfile with additional AnalyticsProperties
    /*
    if (userProfile.properties != null) {
      var userAttributesBuilder = ListMultimapBuilder<String, String>();
      userProfile.properties!.getAllProperties().forEach((key, value) {
        userAttributesBuilder.add(key, value.toString());
      });
      userBuilder.userAttributes = userAttributesBuilder;
    }
     */

    _endpointBuilder.user = newUserBuilder;

    await updateEndpoint();
  }

  // execute update
  Future<void> updateEndpoint() async {
    // TODO : how to put client markers (ie. user agent) in request?
    await _pinpointClient.updateEndpoint(UpdateEndpointRequest(
        applicationId: _appId,
        endpointId: _sharedPrefs.getUniqueId(),
        endpointRequest: endpointToRequest(_endpointBuilder.build())));
  }

  EndpointRequest endpointToRequest(PublicEndpoint publicEndpoint) {
    return EndpointRequest(
        address: publicEndpoint.address,
        attributes: BuiltListMultimap(_globalFieldsManager.globalAttributes),
        channelType: publicEndpoint.channelType,
        demographic: publicEndpoint.demographic,
        effectiveDate: publicEndpoint.effectiveDate,
        endpointStatus: publicEndpoint.endpointStatus,
        location: publicEndpoint.location,
        metrics: BuiltMap(_globalFieldsManager.globalMetrics),
        optOut: publicEndpoint.optOut,
        requestId: publicEndpoint.requestId,
        user: publicEndpoint.user);
  }
}
