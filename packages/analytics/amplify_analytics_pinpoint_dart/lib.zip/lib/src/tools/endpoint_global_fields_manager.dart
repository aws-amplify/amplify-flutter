import 'dart:collection';
import 'dart:convert';
import 'dart:math';

import 'package:built_collection/built_collection.dart';

import 'analytics_client/flutter_shared_prefs.dart';

class EndpointGlobalFieldsManager {
  final int _max_key_length = 50;
  final int _max_attribute_values = 50;
  final int _max_attributes = 20;
  final int _max_attribute_value_length = 100;

  late final Map<String, List<String>> _globalAttributes;
  late final Map<String, double> _globalMetrics;

  UnmodifiableMapView<String, List<String>> get globalAttributes =>
      UnmodifiableMapView(_globalAttributes);
  UnmodifiableMapView<String, double> get globalMetrics =>
      UnmodifiableMapView(_globalMetrics);

  // External dependencies
  late FlutterSharedPrefs _sharedPrefs;

  EndpointGlobalFieldsManager() {
    _globalAttributes = jsonDecode(
        _sharedPrefs.getJson(FlutterSharedPrefs.endpointGlobalAttrsKey));
    _globalMetrics = jsonDecode(
        _sharedPrefs.getJson(FlutterSharedPrefs.endpointGlobalMetricsKey));
  }

  String processKey(String key) {
    if (key.length > _max_key_length) {
      print(
          'The attribute key has been trimmed to a length of $_max_key_length characters.');
      return key.substring(0, _max_key_length);
    }
    return key;
  }

  List<String> processAttributeValues(List<String> values) {
    List<String> trimmedValues = <String>[];

    // Restrict list length to "_max_attribute_values"
    if (values.length > _max_attribute_values) {
      trimmedValues = values.sublist(0, _max_attribute_values);
      print(
          'The attribute values has been reduced to $_max_attribute_values values.');
    } else {
      trimmedValues = List.from(values);
    }

    // Restrict list element lengths to '_max_attribute_value_length"
    for (int i = 0; i < trimmedValues.length; i++) {
      String value = trimmedValues[i];
      if (value.length > _max_attribute_value_length) {
        value = value.substring(0, _max_attribute_value_length);
        trimmedValues[i] = value;
        print(
            'The attribute value has been trimmed to a length of $_max_attribute_value_length characters');
      }
    }

    return trimmedValues;
  }

  void addAttribute(String name, List<String> values) {
    /// TODO : are atomic updates needed for counter ?

    if (_globalAttributes.length + _globalMetrics.length < _max_attributes) {
      _globalAttributes[processKey(name)] = processAttributeValues(values);
      _saveAttributes();
    } else {
      print(
          'Max number of attributes/metrics reached: $_max_attributes.  Ignoring additional attributes.');
    }
  }

  void removeAttribute(String name) {
    _globalAttributes.remove(name);
    _saveAttributes();
  }

  void _saveAttributes() {
    _sharedPrefs.saveJson(FlutterSharedPrefs.endpointGlobalAttrsKey,
        jsonEncode(_globalAttributes));
  }

  void addMetric(String name, double value) {
    if (_globalAttributes.length + _globalMetrics.length < _max_attributes) {
      _globalMetrics[processKey(name)] = value;
      _saveMetrics();
    } else {
      print(
          'Max number of attributes/metrics reached: $_max_attributes).  Ignoring additional metrics');
    }
  }

  void removeMetric(String name) {
    _globalMetrics.remove(name);
    _saveMetrics();
  }

  void _saveMetrics() {
    _sharedPrefs.saveJson(FlutterSharedPrefs.endpointGlobalMetricsKey,
        jsonEncode(_globalMetrics));
  }
}
